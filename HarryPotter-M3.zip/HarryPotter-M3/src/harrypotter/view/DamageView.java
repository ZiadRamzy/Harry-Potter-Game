package harrypotter.view;

import harrypotter.controller.GameControl;
import harrypotter.model.magic.DamagingSpell;
import harrypotter.model.magic.Spell;
import harrypotter.model.world.Direction;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class DamageView extends JFrame implements KeyListener , ActionListener{
	JPanel main;
	JPanel sub;
	JTextField txt;
	JButton btn;
	GameControl listener;
	Spell s;
	
	public DamageView(Spell s){
		this.s=s;
		//this.setTitle("NAME");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setBounds(getHeight()/2, getWidth()/2, 1100, 150);
		//setLayout(new BorderLayout());
		main=new JPanel();
		JLabel lbl =new JLabel();
		lbl.setText("PLEASE CHOOSE A DIRECTION FOR THE SPELL USING ARROW KEYS");
		lbl.setVisible(true);
		add(main);
		main.add(lbl);
		main.setVisible(true);
		addKeyListener(this);
		this.setVisible(true);
//		sub = new JPanel();
//		sub.setLayout(new GridLayout(0,2));
//		main.setLayout(new FlowLayout());
//		txt=new JTextField();
//		txt.setSize(new Dimension(400,100));
//		txt.setVisible(true);
//		btn=new JButton("Enter");
//		btn.setVisible(true);
//		btn.setSize(new Dimension(50,50));
//		btn.addActionListener(this);
//		lbl =new JLabel("Please enter your name");
//		lbl.setPreferredSize(new Dimension(450,100));
		lbl.setFont(new Font("Harry p", Font.PLAIN, 30));
//		lbl.setVisible(true);
//		add(main,BorderLayout.CENTER);
//		add(sub,BorderLayout.SOUTH);
//		//add(lbl,BorderLayout.CENTER);
//		sub.add(txt);
//		sub.add(btn);
//		main.add(lbl);
//		this.setVisible(true);
		}


	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		String name = txt.getText();
		listener.onName(name);
		
		
	}
	public GameControl getListener() {
		return listener;
	}


	public void setListener(GameControl listener) {
		this.listener = listener;
	}


	public static void main(String[]args){
	    DamagingSpell s =new DamagingSpell("name", 1, 1, 1);
		new DamageView(s);
			
		}


	@Override
	public void keyPressed(KeyEvent e) {
		int code =e.getKeyCode();
		if(code==KeyEvent.VK_UP){
			Direction d=Direction.FORWARD;
				listener.onCastingSpell(s, d,null,0);
				this.dispose();
			//	System.out.println("WORKS");
				}
			
		if(code==KeyEvent.VK_DOWN){
			Direction d=Direction.BACKWARD;
			listener.onCastingSpell(s, d,null,0);
			this.dispose();
		}
		if(code==KeyEvent.VK_LEFT){
			
			Direction d=Direction.LEFT;
			listener.onCastingSpell(s, d,null,0);
			this.dispose();
		}
			
		if(code==KeyEvent.VK_RIGHT){
			
			Direction d=Direction.RIGHT;
			listener.onCastingSpell(s, d,null,0);
			this.dispose();
		}
		
	}


	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
