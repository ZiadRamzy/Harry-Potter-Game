package harrypotter.view;

import javax.swing.JFrame;

public class End extends JFrame{

}
