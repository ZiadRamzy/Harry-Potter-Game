package harrypotter.view;

import harrypotter.controller.GameControl;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javafx.scene.layout.Border;
import javafx.scene.paint.Color;
import javafx.stage.Popup;

import javax.imageio.ImageIO;
import javax.print.DocFlavor.URL;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.UIManager;

public class Intro extends JFrame implements ActionListener{
	JPanel main;
	JButton start;
	GameControl listener;
	public Intro(){
		//(0, 0, 100, 1600);
		setExtendedState(MAXIMIZED_BOTH);
		setUndecorated(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		main =  new JPanel();
		main.setLayout(null);

		//JLayeredPane layer = new JLayeredPaneame();
		//layer.setSize(100, 100);
		
		BufferedImage img = null;
		try {
			img =ImageIO.read(new File("CMWTqJx.jpg"));		
			} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Image h = img.getScaledInstance(getSize().width, getSize().height, img.SCALE_SMOOTH);
		
		JLabel background= new JLabel(new ImageIcon(h));
		background.setSize(getSize());
		background.setVisible(true);
		this.setContentPane(background);
//		getContentPane().add(background);
		//BufferedImage bg =new buff("D:\\0.jpg");
		//this.setIconImage(new Image("D:\\0.jpg"));
		
		
		//main.setBackground();
		start = new JButton("Start Game");
		start.addActionListener(this);
		start.setBounds(getSize().width-350, getSize().height-150, 300, 75);
		start.setToolTipText("   START GAME   ");
		//start.setFont(new Font("Harry P", Font.PLAIN, 45));
		JButton exit = new JButton("EXIT");
		exit.addActionListener(this);
		exit.setBounds(50, getSize().height-150, 300, 75);
		//exit.setFont(new Font("Harry P", Font.PLAIN, 45));
		
//		main.setBackground(java.awt.Color.RED);
//		main.setOpaque(false );
		getContentPane().add(start);
		getContentPane().add(exit);
		revalidate();
		repaint();
	//	add(main);
	//	main.setVisible(true);
		
//		try {
//	         // Open an audio input stream.
//			File soundFile = new File("music.wav");
//			AudioInputStream audioIn = AudioSystem.getAudioInputStream(soundFile);
//	         // Get a sound clip resource.
//	         Clip clip = AudioSystem.getClip();
//	         // Open audio clip and load samples from the audio input stream.
//	         clip.open(audioIn);
//	         clip.start();
//	         clip.loop(clip.LOOP_CONTINUOUSLY);
//	      } catch (UnsupportedAudioFileException e) {
//	         e.printStackTrace();
//	      } catch (IOException e) {
//	         e.printStackTrace();
//	      } catch (LineUnavailableException e) {
//	         e.printStackTrace();
//	      }
		//ImageIcon icon = new ImageIcon("C:/Users/Mostafa/Desktop/Harry Potter Media/cupGif.gif");
		
		
		
		
	   }
	   
		
	
public static void main(String[]args){
	new Intro();
}
public JPanel getMain() {
	return main;
}
public void setMain(JPanel main) {
	this.main = main;
}
public JButton getStart() {
	return start;
}
public void setStart(JButton start) {
	this.start = start;
}
public GameControl getListener() {
	return listener;
}
public void setListener(GameControl listener) {
	this.listener = listener;
}
@Override
public void actionPerformed(ActionEvent e) {
	JButton btn = (JButton) e.getSource();
	if(btn.getText().equals("Start Game")){
		listener.onStart();
	}
	else{
		listener.onExit();
	}
	
}
}
// JOption pane for exceptions potions and end turn
