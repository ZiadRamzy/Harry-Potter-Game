package harrypotter.view;

import java.awt.Dimension;

import harrypotter.model.character.GryffindorWizard;
import harrypotter.model.character.Wizard;
import harrypotter.model.magic.Potion;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ExceptionView extends JFrame{
	public ExceptionView(Wizard z){
//		JComboBox potions=new JComboBox();
//		for(int i=0;i<z.getInventory().size();i++){
//			potions.addItem(z.getInventory().get(i));
//		}
//		potions.setPreferredSize(new Dimension(200, 200));
//		add(potions);
//		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
//		this.setVisible(true);
		JPanel p=new JPanel();
		p.setPreferredSize(new Dimension(1000,1000));
		String[] petStrings = { "Bird", "Cat", "Dog", "Rabbit", "Pig" };

		//Create the combo box, select item at index 4.
		//Indices start at 0, so 4 specifies the pig.
		JComboBox petList = new JComboBox(petStrings);
		petList.setSelectedIndex(4);
		p.add(petList);
		add(p);
		setVisible(true);
		setExtendedState(MAXIMIZED_BOTH);
	//	petList.addActionListener(this);
		
	}
	public static void main(String[] args) {
		GryffindorWizard z=new GryffindorWizard("NAME");
		Potion p1=new Potion("name1", 10);
		Potion p2=new Potion("name2", 10);
		Potion p3=new Potion("name3", 10);
		Potion p4=new Potion("name4", 10);
		z.getInventory().add(p1);
		z.getInventory().add(p2);
		z.getInventory().add(p3);
		z.getInventory().add(p4);
		new ExceptionView(z);
	}

}
