package harrypotter.model.world;

public class EmptyCell extends Cell {

}
