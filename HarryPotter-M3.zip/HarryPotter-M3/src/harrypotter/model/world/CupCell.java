package harrypotter.model.world;

public class CupCell extends Cell {

}
